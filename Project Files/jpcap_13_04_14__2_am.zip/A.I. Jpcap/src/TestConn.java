
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import net.sourceforge.jpcap.capture.*;
import net.sourceforge.jpcap.net.*;
import net.sourceforge.jpcap.util.Timeval;

public class TestConn
{
    public static String m_device;

    public static int sent_Syn_Count = 0;
    
    public static int total_Packet_Count = 0;
    public static int sent_Fin_Count = 0;
    
    public static int conn_Init_Count = 0;
    public static int conn_Term_Count = 0;
    
    public static long[] client_seq_no = new long[100];
    public static long[] server_seq_no = new long[100];
    
    public static Timeval[] start_Time = new Timeval[100];
    public static String[] dst_Server_Socket = new String[100];
    
    public static String[] hostList = new String[100];
    public static String[] endHostList = new String[100];
    
    public static Timeval[] end_Time = new Timeval[100];
    
    public static long[] fin_Client_seq_no = new long[100];
    
    public static long[] fin_Server_seq_no = new long[100];
    public static String[] fin_Server_Socket = new String[100];
    
     public static void main(String[] args)
    {
    	
        try
        {

        	m_device = "\\Device\\NPF_{83F71149-7C4C-4322-8A78-A99B3E977425}"; // my laptop wi-fi interface
        	 PacketCapture pcap = new PacketCapture();
             System.out.println("Using device '" + m_device + "'");
             pcap.open(m_device, 65535, true, 1000);
             pcap.setFilter("ip and tcp", true);

             pcap.addPacketListener(new PacketHandler3());

             System.out.println("Capturing packets...");
             
             pcap.capture(100); // -1 is infinite capturing
             
             System.out.println(" Infinite");
             PacketHandler3 ph = new PacketHandler3();
             
             int k=0,m=0;
             /*
             while(TestConn.start_Time[k] != null)
             {
            	 System.out.println("From Main Start Time: " + TestConn.start_Time[k]);
            	 k++;
             }
             
             while(TestConn.end_Time[m] != null)
             {
            	 System.out.println("End Time: " + TestConn.end_Time[m]);
            	 m++;
             }
             
             */
             
             /*
             for(int i=0;TestConn.start_Time[i] != null;i++)
             {
            	 for(int j=0;TestConn.end_Time[j] != null;j++)
                 {
            		 if( TestConn.fin_Server_Socket[j].equals(TestConn.dst_Server_Socket))
            		 {
            			 long start = TestConn.start_Time[i].getSeconds();
            			 long end = TestConn.end_Time[j].getSeconds();
            			 long diff = end - start;
            			 System.out.println("Conn. Duration:  " + diff);
            		 }
                 }
            	 
             }
             
             for(int i=0;TestConn.start_Time[i] != null;i++)
             {
            	 System.out.println("Start Time: " + TestConn.start_Time[i]+ " Host: " + TestConn.hostList[i]);
             }
             
             for(int j=0;TestConn.end_Time[j] != null;j++)
             {
             		
             		System.out.println("End Time: " + TestConn.end_Time[j] + " Host: " + TestConn.endHostList[j] );
             }
             */
             
             for(int i=0;TestConn.fin_Server_Socket[i] != null;i++)
             {
            	 System.out.println("Server Addr. who sent FIN=1 : " + fin_Server_Socket[i]);
             }
             
             System.out.println("Syn Count: " + TestConn.sent_Syn_Count);
             System.out.println("Fin Count: " + TestConn.sent_Fin_Count);
             System.out.println("Total Packet Count: " + TestConn.total_Packet_Count);
             System.out.println("Terminated");
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

class PacketHandler3 implements PacketListener {
    BufferedOutputStream stream;
    
    public PacketHandler3() throws IOException {
    	//System.out.println("Reset Count from Pkt Handler: " + reset_Count);
        
    }

    @Override
	public void packetArrived(Packet packet) {
        try {
            // only handle TCP packets

            if(packet instanceof TCPPacket) {
                TCPPacket tcpPacket = (TCPPacket)packet;
                
                TestConn.total_Packet_Count++;
                String src_IP = tcpPacket.getSourceAddress();
                int src_Port = tcpPacket.getSourcePort();
                String src_Socket = src_IP+":"+src_Port;
                
                boolean syn,ack,rst,fin,psh,urg;
                syn = tcpPacket.isSyn();
                ack = tcpPacket.isAck();
                fin = tcpPacket.isFin();
              
                
                String dst_IP = tcpPacket.getDestinationAddress();  // dst_ip in string
                int dst_Port = tcpPacket.getDestinationPort();
                String dst_Socket = dst_IP+":"+dst_Port;
                
                //System.out.println("Dst IP: " + dst_IP);
                InetAddress local = InetAddress.getLocalHost();
                String local_ip = String.valueOf(local);
                int pos_Backslash = local_ip.indexOf("/");

                local_ip = local_ip.substring(pos_Backslash+1);   // local_ip in string
                
               // start of checking for COnn. Initiation
                
                if(src_IP.equals(local_ip))
                {
                    if(syn)
                    {
                    	TestConn.sent_Syn_Count++;
                    	TestConn.client_seq_no[TestConn.sent_Syn_Count - 1] = tcpPacket.getSequenceNumber(); 
                    }
                }

                if(dst_IP.equals(local_ip))   // 2nd part of COnn. Init
                {
                	if(syn)
                	{
                		for(int i=0;i<TestConn.client_seq_no.length;i++)
                		{
                			if(tcpPacket.getAcknowledgementNumber() == TestConn.client_seq_no[i]+1)
                    		{
                    			TestConn.dst_Server_Socket[i] = dst_Socket;
                    			TestConn.server_seq_no[i] = tcpPacket.getSequenceNumber();
                    		}
                		}
                	}
                }
                
                
                if(src_IP.equals(local_ip))
                {
                    if(ack)
                    {
                    	for(int i=0; i<TestConn.server_seq_no.length;i++)
                    	{
                    		if(tcpPacket.getAcknowledgementNumber() == TestConn.server_seq_no[i]+1) // part 3 of conn. init
                        	{
                        		// conn. is established..
                    			TestConn.start_Time[i] = tcpPacket.getTimeval();
                    			
                    			InetAddress addr = InetAddress.getByName(tcpPacket.getDestinationAddress());
                    			TestConn.hostList[i] = addr.getHostName();
                        		
                    			//System.out.println("Start Time" + TestConn.start_Time[i]);
                    			//System.out.println("Conn. Established to " + dst_Socket+" at "+ TestConn.start_Time[i]);
                    			TestConn.conn_Init_Count++;
                        	}
                    	}
                    }
                }
           // End of checking for COnn. Initiation             
                
                
           // Start of Checking for Conn. termination
                if(src_IP.equals(local_ip) /* || dst_IP.equals(local_ip)*/ )
                {
                	if(fin)
                	{
                		TestConn.sent_Fin_Count++;
                		TestConn.fin_Client_seq_no[TestConn.sent_Fin_Count-1] = tcpPacket.getSequenceNumber(); 
                	}
                }
                
                if(dst_IP.equals(local_ip))
                {
                	if(fin)
                	{
                		for(int i=0;i<TestConn.fin_Client_seq_no.length;i++)
                		{
	                		if(tcpPacket.getAcknowledgementNumber() == TestConn.fin_Client_seq_no[i]+1)
	                		{
	                			
	                			TestConn.fin_Server_seq_no[i] = tcpPacket.getSequenceNumber();
	                		}
                		}
                	}
                }
                
                if(src_IP.equals(local_ip) /* || dst_IP.equals(local_ip)*/ )
                {
                	if(ack)
                	{
                		for(int i=0;i<TestConn.fin_Server_seq_no.length;i++)
                		{
                			if(tcpPacket.getAcknowledgementNumber() == TestConn.fin_Server_seq_no[i]+1)
                    		{
                        		TestConn.conn_Term_Count++;
                        		TestConn.end_Time[i] = tcpPacket.getTimeval();
                        		TestConn.fin_Server_Socket[i] = dst_Socket; 
                        		
                        		InetAddress addr = InetAddress.getByName(tcpPacket.getDestinationAddress());
                        		TestConn.endHostList[i] = addr.getHostName();

                        		
                    		}
                		}
                		
                		 
                	}
                }
                
                
          // End of Checking for Conn. termination
            }
        } catch( Exception e ) {
            e.printStackTrace(System.out);
        }
    }
}
