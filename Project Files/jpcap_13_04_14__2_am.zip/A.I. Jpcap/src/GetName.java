import java.net.*;

public class GetName 
{
	public static void main(String args[]) throws UnknownHostException
	{
		 InetAddress addr = InetAddress.getByName("8.8.8.8");
		  String host = addr.getHostName();
		  System.out.println(host);
	}
}
