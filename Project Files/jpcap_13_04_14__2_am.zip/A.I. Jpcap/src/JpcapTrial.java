import jpcap.JpcapCaptor;
import jpcap.NetworkInterface;
import net.sourceforge.jpcap.capture.CaptureDeviceLookupException;
import net.sourceforge.jpcap.capture.CaptureDeviceNotFoundException;
import net.sourceforge.jpcap.capture.PacketCapture;
public class JpcapTrial {
	
	
	public static void main(String args[]) throws CaptureDeviceLookupException{
		
		PacketCapture capture = new PacketCapture();
		   
		   
		   
		   String[] interfaces = PacketCapture.lookupDevices(); 
		   
		   for(int i=0;i< interfaces.length; i++)
		   {
			   System.out.println("Interface "+ i + " :  "+interfaces[i]);
		   }
	}
}