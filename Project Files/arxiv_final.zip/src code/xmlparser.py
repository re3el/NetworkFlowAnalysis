#!/usr/bin/python

from xml.dom.minidom import parse
import urllib2, json, xml.dom.minidom, sys, noResults
from noResults import InvalidAPIUsage


def getjson(request_URL):
	# Open XML document using minidom parser
	headers = { 'User-Agent' : 'Mozilla/5.0' }
	req = urllib2.Request(request_URL, None, headers)
	
	# Using DOMTree to parse the Atom feed received from arxiv
	DOMTree = xml.dom.minidom.parse(urllib2.urlopen(req))
	
	# Getting handle to collection of elements in the DOM Tree
	collection = DOMTree.documentElement

	# total returned results
	total_results = collection.getElementsByTagName("opensearch:totalResults")[0].childNodes[0].data
	
	# If results returned is 0, then raise an exception
	if total_results == '0':
		raise InvalidAPIUsage('Search query doesn\'t match any records', status_code=404)
		
	# Get all the entries in the collection
	entries = collection.getElementsByTagName("entry")
	
	# Incase of Wrong journal id, we get total_results = 1 saying it is wrong ID (contains error messages). 
	# So above case checking for total_results = 0 won't work
	# So check for first element's Title tag and if it matches 'Error', that means journal ID supplied is invalid
	
	title_first_element = entries[0].getElementsByTagName('title')[0].childNodes[0].data
	if title_first_element == 'Error':
		raise InvalidAPIUsage('Search query doesn\'t match any records', status_code=404)
			
	# Creating empty json object 'data'
	data = []
	
	# looping through all entries (journals) and append details of each journal into data object

	for entry in entries:
		j_id = entry.getElementsByTagName('id')[0].childNodes[0].data
		published = entry.getElementsByTagName('published')[0].childNodes[0].data
		title = entry.getElementsByTagName('title')[0].childNodes[0].data
		summary = entry.getElementsByTagName('summary')[0].childNodes[0].data
		authors = entry.getElementsByTagName("name")
		authors_names = []
		for author in authors:
			author_ = author.childNodes[0].nodeValue
			new_entry = { 'name': author_ }
			authors_names.append(new_entry)
		new_entry = { 'id': j_id , 'published': published, 'title': title, 'summary': summary, 'author': authors_names}
		data.append(new_entry)
	
	# To create entry key in json to return to the user
	data = {'entry':data}
	return data

#getjson(request_URL)
