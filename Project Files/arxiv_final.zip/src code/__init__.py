from flask import render_template, flash, redirect, url_for,request,session,Flask,jsonify,abort,make_response
from time import gmtime, strftime
from getbyAuthor import getbyAuthor
from getbyJournalId import getbyJournalId
from getbyJournalTitle import getbyJournalTitle
from getbyCategory import getbyCategory
from getbyJournalAbs import getbyJournalAbs
from getbySearchAll import getbySearchAll
from flask.ext.cors import CORS
from noResults import InvalidAPIUsage
from flask.ext.httpauth import HTTPBasicAuth

import xml.etree.ElementTree as ET, urllib2
import requests,json,urllib,ConfigParser,random,base64,hmac,binascii,time,collections,hashlib,json,argparse,glob,datetime,time,urllib2
import os, sys

app = Flask(__name__)
cors = CORS(app)
auth = HTTPBasicAuth()


def is_float(str):
	try:
		float(str)
		return True
	except Exception:
		return False

def getInstitution(search_Str,user,password):
	url="http://129.128.184.88/api/getInstitution/"
	url=url+search_Str
	print url
	#user="cmput402"
	#password="qpskcnvb"
	sciverse_response = requests.get(url,auth=(user,password))

	if sciverse_response.status_code==200:
		data = json.loads(sciverse_response.text)
		print "received response from Sciverse"
		results = strftime("%Y-%m-%d %H:%M:%S", gmtime())
		#results = 'file'
                f=open("/var/www/arxiv_adapter/arxiv_adapter/static/data/"+results+".js",'w+')
		f.write(json.dumps(data))
		f.close()

		print "created file.js and creating modified file_new.js"

		wfile = open("/var/www/arxiv_adapter/arxiv_adapter/static/data/"+results+'_new.js','w+');
		fstr = '{\"items\":[';
		i=0;
		for row in data['entry']:
			row['label'] = row['Instit_name'] + ', ' + row['document_count']
			row['location'] = row['city']
			j_str = json.dumps(row);
			if(i==0):
				fstr = fstr + j_str;
			else:
				fstr = fstr +","+j_str;
			i=1;
		fstr = fstr+']}'
		wfile.write(fstr);

		print "created modified file_new.js"

		for file in glob.glob('/var/www/arxiv_adapter/arxiv_adapter/static/locations/*'):
			rfile = open(file)
			locations = rfile.readlines()	
					#locations = file.readlines()
					#file.close()
					#os.rename(file,"static/locations/.txt")

		for i in xrange(len(locations)):
			locations[i] = locations[i][:-1]

		for i in xrange(len(locations)):
			locations[i] = locations[i].split('\t')[0]

		print locations

		locations.remove(locations[0])

		print locations

		print locations  # locations array contains all locations for which coordinates are cached

		print "loaded cached location coordinates"

		#f=open("app/static/data/cities.txt",'w')
		
		cities = set()  # cities set contains set of cities returned in the current request
		for row in data['entry']:
			cities.add(row['location'])

		print cities
		print "extracted cities from response file"
		
		for file in glob.glob('/var/www/arxiv_adapter/arxiv_adapter/static/locations/*'):
			wfile = open(file,'a')

		for city in cities:
			if city not in locations:
				print 'not cached, sending request to openstreetmap.org for coordinates'
				url = 'http://nominatim.openstreetmap.org/search?city='+city
				html_data = urllib2.urlopen(url)
				#result = json.loads(html_data)
				data = html_data.read()
				searchstr = data[-700:]
				searchstr = searchstr.split('\n');
				long = data[-100:-90]
				lat = data[-88:-78]
				for tstr in searchstr:
					if(tstr.find("panToLatLonBoundingBox")!=-1):
						tstr = tstr.split('(')[1]
						tstr = tstr.split(',')
						lat = abs(float(tstr[0]))
						long = abs(float(tstr[1]))
				printstr = city+"\tlocation\t"+str(lat)+","+str(long)+"\n"

				if(is_float(long) and is_float(lat)):
						wfile.write(printstr)
						print "coordinates fetched and stored for city "+ city
			else:
				print 'Using cached coordinates.'


		print "coordinates for all cities are fetched and getInstitution method is going to exit now"
		for file in glob.glob('/var/www/arxiv_adapter/arxiv_adapter/static/locations/*'):
			os.rename(file,"/var/www/arxiv_adapter/arxiv_adapter/static/locations/"+results+"_new.txt")

		return results

@auth.get_password
def get_password(username):
    if username == 'cmput402':
        return 'qpskcnvb'
    return None

# Handling unauthorized access errors
@auth.error_handler
def unauthorized():
	return handle_invalid_usage (InvalidAPIUsage('401 - Unauthorized access. Please provide valid credentials', status_code=401))


# Handling 404 page not found errors
@app.errorhandler(404)
def page_not_found(e):
	return handle_invalid_usage (InvalidAPIUsage('404 - Page not Found', status_code=404))
    #return render_template('404.html'), 404
    #return make_response(jsonify({'error':'Page not found'}),404)


# Error handler class to handler exceptions raised
@app.errorhandler(InvalidAPIUsage)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response

# Handling HTTP Bad Request errors
@app.errorhandler(urllib2.HTTPError)
def bad_request_m(e):
	return handle_invalid_usage (InvalidAPIUsage('400 - Bad Request', status_code=400))
    

    
@app.route('/app',methods=['GET','POST'])
def index():
    error=None

    if 'name' not in session or 'password' not in session :
		return redirect(url_for('login'))
    else:
		if request.method=='POST':
			if request.form['search_Str']!='':
				user=session['name']
				password=session['password']
				
				search_Str=request.form['search_Str']			
				results = getInstitution(search_Str,user,password)
				#results = 'file_new'
				print results
				results = results+'_new'

				#print search_Str
				return render_template("new.html",filename=results)
			else:
				error="No search_Str provided"

    		return render_template("app.html",error=error)

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    
    if request.method == 'POST':
        if request.form['username'] != 'cmput402' or request.form['password'] != 'qpskcnvb':
            error = 'Invalid Credentials. Please try again.'
        else:
	    session['name']=request.form['username']
	    session['password']=request.form['password']
            return redirect(url_for('index'))
    
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    files=glob.glob('arxiv_adapter/static/data/*')
    for f in files:
    	os.remove(f)
    session.pop('name', None)
    return redirect(url_for('login'))


@app.route('/output')
def output():
	if 'name' not in session or 'password' not in session:
		return redirect(url_for('login')) 
	else:
		return render_template("new.html")

@app.route('/')
def list_methods():
    if 'name' not in session or 'password' not in session :
		return redirect(url_for('login'))
    else:
    	return render_template('index.html')

@app.route('/about')
def about():
    if 'name' not in session or 'password' not in session :
		return redirect(url_for('login'))
    else:
    	return render_template('about.html')	

# Method to search by author name
@app.route('/api/v1.0/author/<path:search_str>', methods=['GET'])
@auth.login_required
def author(search_str):
	return jsonify(getbyAuthor(search_str))

# Method to search by journal id
@app.route('/api/v1.0/journal_id/<path:search_str>', methods=['GET'])
@auth.login_required
def journal_id(search_str):
	return jsonify(getbyJournalId(search_str))
	
# Method to search by journal title	
@app.route('/api/v1.0/journal_title/<path:search_str>', methods=['GET'])
@auth.login_required
def journal_title(search_str):
	return jsonify(getbyJournalTitle(search_str))
	
	
# Method to search by category	
@app.route('/api/v1.0/category/<path:search_str>', methods=['GET'])
@auth.login_required
def category(search_str):
	return jsonify(getbyCategory(search_str))
	
# Method to search by journal abstract	
@app.route('/api/v1.0/journal_abs/<path:search_str>', methods=['GET'])
@auth.login_required
def journal_abs(search_str):
	return jsonify(getbyJournalAbs(search_str))

# Method to search by in all fields
@app.route('/api/v1.0/search_all/<path:search_str>', methods=['GET'])
@auth.login_required
def search_all(search_str):
	return jsonify(getbySearchAll(search_str))
				

app.secret_key="dafeae"

if __name__ == '__main__':
    app.secret_key="dafeae"
    app.run(debug=True)
