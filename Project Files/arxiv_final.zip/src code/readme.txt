Team Twitter's and Team Arxiv's adapters are built on Flask Micro Framework. To set it up, you can see "installing and setting up flask.txt"
Team Pubmed's adapter is built using HTML and JS

We followed http://blog.miguelgrinberg.com/post/designing-a-restful-api-with-python-and-flask for help with flask.


It takes time for visualizations to load data. So please be patient.

For accessing Visualizations:


Username and password: cmput402 and qpskcnvb

Team Arxiv's Visualization: http://162.246.156.46
Team Twitter's Visualization: http://162.246.156.47/app/login
Team Pubmed's Visualization: http://162.246.156.52/visualization/index.html

For pubmed adapter, when it asks for authentication in browser click cancel and it redirects you to a login page. Use above credentials there to login.


