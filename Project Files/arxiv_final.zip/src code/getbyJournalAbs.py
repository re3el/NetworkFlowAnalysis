#! flask/bin/python

from xmlparser import getjson

def getbyJournalAbs(search_str):

	# initialising variables to construct search query
	
	start = 'start=0'
	max_results = 'max_results=10'
	query_URL = 'http://export.arxiv.org/api/query?search_query='
	args = search_str.split('&')
	search_str = 'abs:' + args[0].replace(' ','%20')
	
	# checking if user has given start and max_results variables.
	
	if( len(args) == 2 ):
		if 'start' in str(args[1]):
			start = str(args[1])
		elif 'max_results' in str(args[1]):
			max_results = str(args[1])
	elif(len(args) == 3):
		start = str(args[1])
		max_results = str(args[2])
	
	# final search URL
	query_URL += search_str + '&' + start + '&' + max_results
	
	# this gets json (dictionary) from xmlparser.py
	return getjson(query_URL)
